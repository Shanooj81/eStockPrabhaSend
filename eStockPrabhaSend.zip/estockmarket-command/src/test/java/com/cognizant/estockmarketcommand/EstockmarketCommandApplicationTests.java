package com.cognizant.estockmarketcommand;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstockmarketCommandApplicationTests {

	@Test
	void contextLoads() {
	}

}
