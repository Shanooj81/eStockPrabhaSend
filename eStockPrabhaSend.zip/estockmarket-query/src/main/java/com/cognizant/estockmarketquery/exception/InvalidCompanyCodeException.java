package com.cognizant.estockmarketquery.exception;

public class InvalidCompanyCodeException extends RuntimeException{

}
